// ===== MODIFY BASE URL IF PORT CHANGES =====
const BASE_URL = "http://localhost:3000";
// ===========================================

// DOM Elements
const authSection = document.getElementById("auth-section");
const dashSection = document.getElementById("dashboard-section");
const loginForm = document.getElementById("login-form");
const signupForm = document.getElementById("signup-form");
const logoutBtn = document.getElementById("logout-btn");
const userNameEl = document.getElementById("user-name");
const profileInfo = document.getElementById("profile-info");
const authMessage = document.getElementById("auth-message");
const tabs = document.querySelectorAll(".tab");

// ===== TAB SWITCHING =====
tabs.forEach(tab => {
  tab.addEventListener("click", () => {
    tabs.forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    const which = tab.dataset.tab;
    loginForm.style.display = which === "login" ? "block" : "none";
    signupForm.style.display = which === "signup" ? "block" : "none";
    hideMessage();
  });
});

// ===== CHECK IF ALREADY LOGGED IN =====
function checkAuth() {
  const token = localStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user") || "null");
  if (token && user) {
    showDashboard(user, token);
  }
}

// ===== LOGIN =====
loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("login-email").value.trim();
  const password = document.getElementById("login-password").value;

  try {
    const res = await fetch(`${BASE_URL}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (!res.ok) return showMessage(data.error || "Login failed", "error");

    // Save to localStorage
    localStorage.setItem("token", data.token);
    localStorage.setItem("user", JSON.stringify(data.user));

    showMessage("✅ Login successful!", "success");
    setTimeout(() => showDashboard(data.user, data.token), 500);
  } catch (err) {
    showMessage("Network error: " + err.message, "error");
  }
});

// ===== SIGNUP =====
signupForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  // ===== ADD FIELDS HERE =====
  const username = document.getElementById("signup-username").value.trim();
  const email = document.getElementById("signup-email").value.trim();
  const password = document.getElementById("signup-password").value;

  const payload = { username, email, password };
  // ===========================

  try {
    const res = await fetch(`${BASE_URL}/signup`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) return showMessage(data.error || "Signup failed", "error");

    localStorage.setItem("token", data.token);
    localStorage.setItem("user", JSON.stringify(data.user));

    showMessage("✅ Account created!", "success");
    setTimeout(() => showDashboard(data.user, data.token), 500);
  } catch (err) {
    showMessage("Network error: " + err.message, "error");
  }
});

// ===== SHOW DASHBOARD =====
async function showDashboard(user, token) {
  authSection.style.display = "none";
  dashSection.style.display = "block";

  // ===== MODIFY DISPLAY FIELD =====
  userNameEl.textContent = user.username;
  // ================================

  // Fetch full profile from server
  try {
    const res = await fetch(`${BASE_URL}/profile`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const profile = await res.json();
    if (res.ok) {
      profileInfo.innerHTML = `
        <div class="profile-row">
          <span class="profile-label">Username</span>
          <span>${profile.username}</span>
        </div>
        <div class="profile-row">
          <span class="profile-label">Email</span>
          <span>${profile.email}</span>
        </div>
        <div class="profile-row">
          <span class="profile-label">Member since</span>
          <span>${new Date(profile.createdAt).toLocaleDateString()}</span>
        </div>
      `;
    }
  } catch {}
}

// ===== LOGOUT =====
logoutBtn.addEventListener("click", () => {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  authSection.style.display = "flex";
  dashSection.style.display = "none";
  loginForm.reset();
  signupForm.reset();
});

// ===== HELPERS =====
function showMessage(msg, type) {
  authMessage.textContent = msg;
  authMessage.className = `message ${type}`;
  authMessage.style.display = "block";
}
function hideMessage() {
  authMessage.style.display = "none";
}

// ===== INIT =====
checkAuth();
