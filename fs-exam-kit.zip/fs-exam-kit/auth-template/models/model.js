const mongoose = require("mongoose");
const bcrypt = require("bcrypt");

// ===== MODIFY ENTITY NAME HERE =====
// Change "User" to your entity name if needed (usually keep as User)
const userSchema = new mongoose.Schema(
  {
    // ===== ADD FIELDS HERE =====
    username: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: true,
    },
    // ===== ADD MORE FIELDS ABOVE THIS LINE =====
    // e.g., role: { type: String, default: "user" },
  },
  { timestamps: true }
);

// Hash password before saving
userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

// Method to compare passwords
userSchema.methods.comparePassword = function (plainPassword) {
  return bcrypt.compare(plainPassword, this.password);
};

// ===== MODIFY ENTITY NAME HERE =====
module.exports = mongoose.model("User", userSchema);
// ====================================
