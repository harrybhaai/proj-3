const express = require("express");
const cors = require("cors");
const path = require("path");
const connectDB = require("./db");

const app = express();

// ===== MODIFY PORT HERE IF NEEDED =====
const PORT = 3000;
// ======================================

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Connect to MongoDB
connectDB();

// Auth Routes
const authRoutes = require("./routes/api");
app.use("/", authRoutes);

// Serve frontend
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
