const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const fs = require("fs");

// ===== MODIFY ENTITY NAME HERE =====
const FileRecord = require("../models/model");
// ====================================

// ===== MULTER CONFIGURATION =====
const UPLOADS_DIR = path.join(__dirname, "../uploads");

// Create uploads directory if it doesn't exist
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    // Unique filename: timestamp + original name
    const uniqueName = `${Date.now()}-${file.originalname.replace(/\s+/g, "_")}`;
    cb(null, uniqueName);
  },
});

// ===== MODIFY ALLOWED FILE TYPES HERE =====
const fileFilter = (req, file, cb) => {
  const allowed = ["image/jpeg", "image/png", "image/gif", "image/webp", "application/pdf", "text/plain"];
  if (allowed.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error("File type not allowed. Accepted: jpg, png, gif, webp, pdf, txt"), false);
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024, // ===== MODIFY MAX FILE SIZE (5MB default) =====
  },
});
// ==========================================

// POST /upload - Upload a file
router.post("/upload", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    // ===== ADD FIELDS HERE =====
    const { description, uploadedBy } = req.body;

    const record = new FileRecord({
      originalName: req.file.originalname,
      filename: req.file.filename,
      mimetype: req.file.mimetype,
      size: req.file.size,
      path: `/uploads/${req.file.filename}`,
      description: description || "",
      uploadedBy: uploadedBy || "Anonymous",
    });
    // ===========================
    await record.save();

    res.status(201).json({
      message: "File uploaded successfully",
      file: record,
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// GET /files - Get all uploaded files
router.get("/files", async (req, res) => {
  try {
    const files = await FileRecord.find().sort({ createdAt: -1 });
    res.json(files);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /files/:id - Delete a file
router.delete("/files/:id", async (req, res) => {
  try {
    const record = await FileRecord.findById(req.params.id);
    if (!record) return res.status(404).json({ error: "File not found" });

    // Delete actual file from disk
    const filePath = path.join(UPLOADS_DIR, record.filename);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

    await FileRecord.findByIdAndDelete(req.params.id);
    res.json({ message: "File deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Error handler for Multer
router.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    return res.status(400).json({ error: `Upload error: ${err.message}` });
  }
  if (err) {
    return res.status(400).json({ error: err.message });
  }
  next();
});

module.exports = router;
