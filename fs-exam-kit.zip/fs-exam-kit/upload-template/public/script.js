// ===== MODIFY BASE URL IF PORT CHANGES =====
const BASE_URL = "http://localhost:3000";
// ===========================================

let selectedFile = null;

// DOM Elements
const dropZone = document.getElementById("drop-zone");
const fileInput = document.getElementById("file-input");
const filePreview = document.getElementById("file-preview");
const fileNameEl = document.getElementById("file-name");
const clearFileBtn = document.getElementById("clear-file");
const uploadBtn = document.getElementById("upload-btn");
const descInput = document.getElementById("description");
const byInput = document.getElementById("uploaded-by");
const filesList = document.getElementById("files-list");
const countEl = document.getElementById("count");
const messageEl = document.getElementById("message");
const progressBar = document.getElementById("upload-progress");
const progressFill = document.getElementById("progress-fill");

// ===== DROP ZONE EVENTS =====
dropZone.addEventListener("click", () => fileInput.click());

dropZone.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropZone.classList.add("dragover");
});
dropZone.addEventListener("dragleave", () => dropZone.classList.remove("dragover"));
dropZone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropZone.classList.remove("dragover");
  const file = e.dataTransfer.files[0];
  if (file) setFile(file);
});

fileInput.addEventListener("change", () => {
  if (fileInput.files[0]) setFile(fileInput.files[0]);
});

function setFile(file) {
  selectedFile = file;
  fileNameEl.textContent = `${file.name} (${formatBytes(file.size)})`;
  filePreview.style.display = "flex";
  uploadBtn.disabled = false;
}

clearFileBtn.addEventListener("click", () => {
  selectedFile = null;
  fileInput.value = "";
  filePreview.style.display = "none";
  uploadBtn.disabled = true;
});

// ===== UPLOAD FILE =====
uploadBtn.addEventListener("click", async () => {
  if (!selectedFile) return showMessage("Please select a file first!", "error");

  const formData = new FormData();
  // ===== ADD FIELDS HERE =====
  formData.append("file", selectedFile);
  formData.append("description", descInput.value.trim());
  formData.append("uploadedBy", byInput.value.trim() || "Anonymous");
  // ===========================

  uploadBtn.disabled = true;
  progressBar.style.display = "block";
  simulateProgress();

  try {
    const res = await fetch(`${BASE_URL}/upload`, {
      method: "POST",
      body: formData,
      // Do NOT set Content-Type header — browser sets it with boundary automatically
    });

    const data = await res.json();
    progressFill.style.width = "100%";

    if (!res.ok) {
      return showMessage(data.error || "Upload failed", "error");
    }

    showMessage("✅ File uploaded successfully!", "success");

    // Reset form
    selectedFile = null;
    fileInput.value = "";
    filePreview.style.display = "none";
    descInput.value = "";
    byInput.value = "";
    uploadBtn.disabled = true;

    setTimeout(() => {
      progressBar.style.display = "none";
      progressFill.style.width = "0%";
    }, 800);

    fetchFiles();
  } catch (err) {
    showMessage("Network error: " + err.message, "error");
  } finally {
    uploadBtn.disabled = false;
  }
});

// ===== FETCH FILES LIST =====
async function fetchFiles() {
  try {
    const res = await fetch(`${BASE_URL}/files`);
    const files = await res.json();
    renderFiles(files);
  } catch (err) {
    showMessage("Failed to load files: " + err.message, "error");
  }
}

// ===== RENDER FILES =====
function renderFiles(files) {
  countEl.textContent = files.length;
  if (!files.length) {
    filesList.innerHTML = '<p class="empty-state">No files uploaded yet.</p>';
    return;
  }

  // ===== MODIFY DISPLAY FIELD =====
  filesList.innerHTML = files.map(file => `
    <div class="file-item">
      <div class="file-icon">${getFileIcon(file.mimetype)}</div>
      <div class="file-info">
        <div class="file-original-name">${file.originalName}</div>
        <div class="file-meta">
          ${formatBytes(file.size)} &nbsp;|&nbsp; 
          ${file.uploadedBy} &nbsp;|&nbsp; 
          ${new Date(file.createdAt).toLocaleDateString()}
          ${file.description ? ` &nbsp;|&nbsp; ${file.description}` : ""}
        </div>
      </div>
      <div class="file-actions">
        <a href="${file.path}" target="_blank">
          <button class="btn-view">👁️ View</button>
        </a>
        <button class="btn-del" onclick="deleteFile('${file._id}')">🗑️ Del</button>
      </div>
    </div>
  `).join("");
  // ================================
}

// ===== DELETE FILE =====
async function deleteFile(id) {
  if (!confirm("Delete this file permanently?")) return;
  try {
    const res = await fetch(`${BASE_URL}/files/${id}`, { method: "DELETE" });
    if (!res.ok) return showMessage("Error deleting file", "error");
    showMessage("🗑️ File deleted", "success");
    fetchFiles();
  } catch (err) {
    showMessage("Network error: " + err.message, "error");
  }
}

// ===== HELPERS =====
function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function getFileIcon(mimetype) {
  if (mimetype.startsWith("image/")) return "🖼️";
  if (mimetype === "application/pdf") return "📄";
  if (mimetype === "text/plain") return "📝";
  return "📁";
}

function simulateProgress() {
  let progress = 0;
  const interval = setInterval(() => {
    progress += Math.random() * 20;
    if (progress >= 90) { clearInterval(interval); return; }
    progressFill.style.width = `${Math.min(progress, 90)}%`;
  }, 200);
}

function showMessage(msg, type) {
  messageEl.textContent = msg;
  messageEl.className = `message ${type}`;
  messageEl.style.display = "block";
  setTimeout(() => (messageEl.style.display = "none"), 3500);
}

// ===== INIT =====
fetchFiles();
