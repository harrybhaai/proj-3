const mongoose = require("mongoose");

// ===== MODIFY ENTITY NAME HERE =====
// This model stores metadata about uploaded files
const fileSchema = new mongoose.Schema(
  {
    // ===== ADD FIELDS HERE =====
    originalName: {
      type: String,
      required: true,
    },
    filename: {
      type: String,
      required: true,
    },
    mimetype: {
      type: String,
      required: true,
    },
    size: {
      type: Number,
      required: true,
    },
    path: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      default: "",
    },
    uploadedBy: {
      type: String,
      default: "Anonymous",
    },
    // ===== ADD MORE FIELDS ABOVE THIS LINE =====
  },
  { timestamps: true }
);

// ===== MODIFY ENTITY NAME HERE =====
module.exports = mongoose.model("FileRecord", fileSchema);
// ====================================
