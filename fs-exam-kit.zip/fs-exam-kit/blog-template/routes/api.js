const express = require("express");
const router = express.Router();

// ===== MODIFY ENTITY NAME HERE =====
const Post = require("../models/model");
// ====================================

// GET all posts
router.get("/", async (req, res) => {
  try {
    // ===== MODIFY FILTER/SORT HERE =====
    const posts = await Post.find().sort({ createdAt: -1 });
    // ====================================
    res.json(posts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single post
router.get("/:id", async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ error: "Post not found" });
    res.json(post);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create post
router.post("/", async (req, res) => {
  try {
    // ===== ADD FIELDS HERE =====
    const { title, author, content, category, tags } = req.body;
    if (!title || !author || !content)
      return res.status(400).json({ error: "Title, author, and content are required" });

    const post = new Post({
      title,
      author,
      content,
      category: category || "General",
      tags: tags ? tags.split(",").map(t => t.trim()) : [],
    });
    // ===========================
    await post.save();
    res.status(201).json(post);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PUT update post
router.put("/:id", async (req, res) => {
  try {
    // ===== ADD FIELDS HERE =====
    const { title, author, content, category, tags } = req.body;
    const updateData = {
      title,
      author,
      content,
      category,
      tags: tags ? tags.split(",").map(t => t.trim()) : [],
    };
    // ===========================
    const updated = await Post.findByIdAndUpdate(req.params.id, updateData, {
      new: true,
      runValidators: true,
    });
    if (!updated) return res.status(404).json({ error: "Post not found" });
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE post
router.delete("/:id", async (req, res) => {
  try {
    const deleted = await Post.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Post not found" });
    res.json({ message: "Post deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
