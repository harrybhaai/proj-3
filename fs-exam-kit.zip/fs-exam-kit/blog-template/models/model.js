const mongoose = require("mongoose");

// ===== MODIFY ENTITY NAME HERE =====
// Change "Post" to your entity name (e.g., "Article", "News", "Entry")
const postSchema = new mongoose.Schema(
  {
    // ===== ADD FIELDS HERE =====
    title: {
      type: String,
      required: true,
      trim: true,
    },
    author: {
      type: String,
      required: true,
      trim: true,
    },
    content: {
      type: String,
      required: true,
    },
    category: {
      type: String,
      default: "General",
      trim: true,
    },
    tags: {
      type: [String],
      default: [],
    },
    // ===== ADD MORE FIELDS ABOVE THIS LINE =====
  },
  { timestamps: true }
);

// ===== MODIFY ENTITY NAME HERE =====
module.exports = mongoose.model("Post", postSchema);
// ====================================
