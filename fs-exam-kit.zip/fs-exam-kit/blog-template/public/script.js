// ===== MODIFY API URL IF PORT CHANGES =====
const API_URL = "http://localhost:3000/posts";
// ==========================================

let editingId = null;

// DOM Elements
const postsGrid = document.getElementById("posts-grid");
const countEl = document.getElementById("count");
const messageEl = document.getElementById("message");
const modalOverlay = document.getElementById("modal-overlay");
const modalTitle = document.getElementById("modal-title");
const postForm = document.getElementById("post-form");
const newPostBtn = document.getElementById("new-post-btn");
const submitBtn = document.getElementById("submit-btn");

// ===== FETCH POSTS =====
async function fetchPosts() {
  try {
    const res = await fetch(API_URL);
    const posts = await res.json();
    renderPosts(posts);
  } catch (err) {
    showMessage("Failed to load posts: " + err.message, "error");
  }
}

// ===== RENDER POSTS =====
function renderPosts(posts) {
  countEl.textContent = posts.length;
  if (!posts.length) {
    postsGrid.innerHTML = '<p class="empty-state">No posts yet. Create the first one!</p>';
    return;
  }

  // ===== MODIFY DISPLAY FIELD =====
  postsGrid.innerHTML = posts.map(post => `
    <div class="post-card">
      <div class="post-category">${post.category || "General"}</div>
      <div class="post-title">${post.title}</div>
      <div class="post-excerpt">${post.content}</div>
      <div class="post-tags">
        ${(post.tags || []).map(t => `<span class="tag">#${t}</span>`).join("")}
      </div>
      <div class="post-meta">✍️ ${post.author} &nbsp;|&nbsp; 📅 ${new Date(post.createdAt).toLocaleDateString()}</div>
      <div class="post-actions">
        <button class="btn btn-sm btn-edit" onclick="startEdit('${post._id}')">✏️ Edit</button>
        <button class="btn btn-sm btn-delete" onclick="deletePost('${post._id}')">🗑️ Delete</button>
      </div>
    </div>
  `).join("");
  // ================================
}

// ===== OPEN MODAL =====
newPostBtn.addEventListener("click", () => openModal());

function openModal(id = null) {
  modalOverlay.style.display = "flex";
  editingId = id;
  modalTitle.textContent = id ? "Edit Post" : "New Post";
  submitBtn.textContent = id ? "💾 Update" : "📝 Publish";
  if (!id) postForm.reset();
}

// ===== CLOSE MODAL =====
document.getElementById("close-modal").addEventListener("click", closeModal);
document.getElementById("close-modal-2").addEventListener("click", closeModal);
modalOverlay.addEventListener("click", (e) => { if (e.target === modalOverlay) closeModal(); });

function closeModal() {
  modalOverlay.style.display = "none";
  editingId = null;
  postForm.reset();
}

// ===== CREATE / UPDATE POST =====
postForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  // ===== ADD FIELDS HERE =====
  const payload = {
    title: document.getElementById("title").value.trim(),
    author: document.getElementById("author").value.trim(),
    content: document.getElementById("content").value.trim(),
    category: document.getElementById("category").value.trim() || "General",
    tags: document.getElementById("tags").value.trim(),
  };
  // ===========================

  if (!payload.title || !payload.author || !payload.content)
    return showMessage("Title, author, and content are required", "error");

  try {
    const url = editingId ? `${API_URL}/${editingId}` : API_URL;
    const method = editingId ? "PUT" : "POST";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const err = await res.json();
      return showMessage(err.error || "Error saving post", "error");
    }

    showMessage(editingId ? "✅ Post updated!" : "✅ Post published!", "success");
    closeModal();
    fetchPosts();
  } catch (err) {
    showMessage("Network error: " + err.message, "error");
  }
});

// ===== START EDIT =====
async function startEdit(id) {
  try {
    const res = await fetch(`${API_URL}/${id}`);
    const post = await res.json();

    document.getElementById("title").value = post.title;
    document.getElementById("author").value = post.author;
    document.getElementById("content").value = post.content;
    document.getElementById("category").value = post.category || "";
    document.getElementById("tags").value = (post.tags || []).join(", ");

    openModal(id);
  } catch (err) {
    showMessage("Failed to load post: " + err.message, "error");
  }
}

// ===== DELETE POST =====
async function deletePost(id) {
  if (!confirm("Delete this post?")) return;
  try {
    const res = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
    if (!res.ok) return showMessage("Error deleting post", "error");
    showMessage("🗑️ Post deleted", "success");
    fetchPosts();
  } catch (err) {
    showMessage("Network error: " + err.message, "error");
  }
}

// ===== SHOW MESSAGE =====
function showMessage(msg, type) {
  messageEl.textContent = msg;
  messageEl.className = `message ${type}`;
  messageEl.style.display = "block";
  setTimeout(() => (messageEl.style.display = "none"), 3000);
}

// ===== INIT =====
fetchPosts();
