// ===== MODIFY API URL IF PORT CHANGES =====
const API_URL = "http://localhost:3000/api/items";
// ==========================================

let editingId = null;

// DOM Elements
const form = document.getElementById("item-form");
const nameInput = document.getElementById("name");
const descInput = document.getElementById("description");
const priceInput = document.getElementById("price");
const itemIdInput = document.getElementById("item-id");
const submitBtn = document.getElementById("submit-btn");
const cancelBtn = document.getElementById("cancel-btn");
const formTitle = document.getElementById("form-title");
const itemsList = document.getElementById("items-list");
const countEl = document.getElementById("count");
const messageEl = document.getElementById("message");

// ===== FETCH ALL ITEMS =====
async function fetchItems() {
  try {
    const res = await fetch(API_URL);
    const items = await res.json();
    renderItems(items);
  } catch (err) {
    showMessage("Failed to load items: " + err.message, "error");
  }
}

// ===== RENDER ITEMS TO DOM =====
function renderItems(items) {
  countEl.textContent = items.length;
  if (items.length === 0) {
    itemsList.innerHTML = '<p class="empty-state">No items yet. Add one above!</p>';
    return;
  }

  // ===== MODIFY DISPLAY FIELD =====
  itemsList.innerHTML = items.map(item => `
    <div class="item-card">
      <div class="item-info">
        <div class="item-name">${item.name}</div>
        <div class="item-meta">
          ${item.description ? `📝 ${item.description}` : ""}
          ${item.price ? ` &nbsp;|&nbsp; 💰 $${parseFloat(item.price).toFixed(2)}` : ""}
        </div>
      </div>
      <div class="item-actions">
        <button class="btn btn-edit" onclick="startEdit('${item._id}', '${escHtml(item.name)}', '${escHtml(item.description)}', '${item.price}')">✏️ Edit</button>
        <button class="btn btn-delete" onclick="deleteItem('${item._id}')">🗑️ Delete</button>
      </div>
    </div>
  `).join("");
  // ================================
}

// ===== CREATE / UPDATE ITEM =====
form.addEventListener("submit", async (e) => {
  e.preventDefault();

  // ===== ADD FIELDS HERE =====
  const payload = {
    name: nameInput.value.trim(),
    description: descInput.value.trim(),
    price: parseFloat(priceInput.value) || 0,
  };
  // ===========================

  if (!payload.name) return showMessage("Name is required!", "error");

  try {
    const url = editingId ? `${API_URL}/${editingId}` : API_URL;
    const method = editingId ? "PUT" : "POST";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const err = await res.json();
      return showMessage(err.error || "Error saving item", "error");
    }

    showMessage(editingId ? "✅ Item updated!" : "✅ Item added!", "success");
    resetForm();
    fetchItems();
  } catch (err) {
    showMessage("Network error: " + err.message, "error");
  }
});

// ===== START EDIT =====
function startEdit(id, name, description, price) {
  editingId = id;
  itemIdInput.value = id;
  nameInput.value = name;
  descInput.value = description;
  priceInput.value = price;
  formTitle.textContent = "✏️ Edit Item";
  submitBtn.textContent = "💾 Update Item";
  cancelBtn.style.display = "inline-block";
  window.scrollTo({ top: 0, behavior: "smooth" });
}

// ===== CANCEL EDIT =====
cancelBtn.addEventListener("click", resetForm);

function resetForm() {
  editingId = null;
  form.reset();
  itemIdInput.value = "";
  formTitle.textContent = "Add New Item";
  submitBtn.textContent = "➕ Add Item";
  cancelBtn.style.display = "none";
}

// ===== DELETE ITEM =====
async function deleteItem(id) {
  if (!confirm("Delete this item?")) return;
  try {
    const res = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
    if (!res.ok) return showMessage("Error deleting item", "error");
    showMessage("🗑️ Item deleted", "success");
    fetchItems();
  } catch (err) {
    showMessage("Network error: " + err.message, "error");
  }
}

// ===== SHOW MESSAGE =====
function showMessage(msg, type) {
  messageEl.textContent = msg;
  messageEl.className = `message ${type}`;
  messageEl.style.display = "block";
  setTimeout(() => (messageEl.style.display = "none"), 3000);
}

// ===== UTILITY =====
function escHtml(str) {
  return (str || "").replace(/'/g, "\\'").replace(/"/g, "&quot;");
}

// ===== INIT =====
fetchItems();
