const mongoose = require("mongoose");

// ===== MODIFY ENTITY NAME HERE =====
// Change "Item" to your entity name (e.g., "Product", "Student", "Task")
const itemSchema = new mongoose.Schema(
  {
    // ===== ADD FIELDS HERE =====
    name: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      default: "",
    },
    price: {
      type: Number,
      default: 0,
    },
    // ===== ADD MORE FIELDS ABOVE THIS LINE =====
  },
  { timestamps: true }
);

// ===== MODIFY ENTITY NAME HERE =====
module.exports = mongoose.model("Item", itemSchema);
// ====================================
